// CellComponents.java
package hw4.maze;

/**
 * Enum representing possible components of a maze cell side.
 */
public enum CellComponents {
    WALL, APERTURE, EXIT
}