// Cell.java
package hw4.maze;

/**
 * Represents a single cell in the maze with directional components (left, right, up, down).
 */
public class Cell {
    private CellComponents left;
    private CellComponents right;
    private CellComponents up;
    private CellComponents down;

    /**
     * Constructs a new Cell with given side components.
     * @param left Left component
     * @param right Right component
     * @param up Up component
     * @param down Down component
     */
    public Cell(CellComponents left, CellComponents right, CellComponents up, CellComponents down) {
        this.left = (left != null) ? left : CellComponents.WALL;
        this.right = (right != null) ? right : CellComponents.WALL;
        this.up = (up != null) ? up : CellComponents.WALL;
        this.down = (down != null) ? down : CellComponents.WALL;
    }

    public CellComponents getLeft() { return left; }
    public CellComponents getRight() { return right; }
    public CellComponents getUp() { return up; }
    public CellComponents getDown() { return down; }

    public void setLeft(CellComponents left) { this.left = (left != null) ? left : CellComponents.WALL; }
    public void setRight(CellComponents right) { this.right = (right != null) ? right : CellComponents.WALL; }
    public void setUp(CellComponents up) { this.up = (up != null) ? up : CellComponents.WALL; }
    public void setDown(CellComponents down) { this.down = (down != null) ? down : CellComponents.WALL; }

    @Override
    public String toString() {
        return "Cell [left=" + left + ", right=" + right + ", up=" + up + ", down=" + down + "]";
    }
}