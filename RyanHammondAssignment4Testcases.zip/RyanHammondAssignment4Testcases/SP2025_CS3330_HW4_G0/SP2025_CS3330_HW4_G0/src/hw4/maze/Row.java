// Row.java
package hw4.maze;

import java.util.ArrayList;

/**
 * Represents a row of cells in the maze grid.
 */
public class Row {
    private ArrayList<Cell> cells;

    /**
     * Constructs a new Row with the given list of cells.
     * @param cells List of Cell objects
     */
    public Row(ArrayList<Cell> cells) {
        this.cells = cells;
    }

    public ArrayList<Cell> getCells() { return cells; }
    public void setCells(ArrayList<Cell> cells) { this.cells = cells; }

    @Override
    public String toString() {
        return "Row [cells=" + cells + "]";
    }
}