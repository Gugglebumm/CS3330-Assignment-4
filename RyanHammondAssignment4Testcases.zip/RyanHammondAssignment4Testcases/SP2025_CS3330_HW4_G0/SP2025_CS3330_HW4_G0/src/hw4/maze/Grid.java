// Grid.java
package hw4.maze;

import java.util.ArrayList;

/**
 * Represents the full maze grid composed of rows of cells.
 */
public class Grid {
    private ArrayList<Row> rows;

    /**
     * Constructs a Grid with the specified list of rows.
     * @param rows The list of Row objects
     */
    public Grid(ArrayList<Row> rows) {
        this.rows = rows;
    }

    public ArrayList<Row> getRows() { return rows; }
    public void setRows(ArrayList<Row> rows) { this.rows = rows; }

    @Override
    public String toString() {
        return "Grid [rows=" + rows + "]";
    }
}
